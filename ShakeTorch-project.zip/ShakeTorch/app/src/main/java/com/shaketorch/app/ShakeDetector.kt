package com.shaketorch.app

import kotlin.math.sqrt

/**
 * Detects a deliberate shake: removes gravity with a low-pass filter, then requires
 * REQUIRED_JOLTS strong accelerations (each separated by at least MIN_GAP_MS)
 * inside a WINDOW_MS window. Walking or pocket movement stays well below the threshold.
 */
class ShakeDetector(private val onShake: () -> Unit) {
    private val gravity = FloatArray(3)
    private var primed = false
    private var jolts = 0
    private var windowStart = 0L
    private var lastJolt = 0L

    fun reset() {
        jolts = 0
        primed = false
    }

    fun onSample(x: Float, y: Float, z: Float, timestampNs: Long, threshold: Float) {
        if (!primed) {
            gravity[0] = x; gravity[1] = y; gravity[2] = z
            primed = true
            return
        }
        val a = ALPHA
        gravity[0] = a * gravity[0] + (1 - a) * x
        gravity[1] = a * gravity[1] + (1 - a) * y
        gravity[2] = a * gravity[2] + (1 - a) * z
        val lx = x - gravity[0]
        val ly = y - gravity[1]
        val lz = z - gravity[2]
        val magnitude = sqrt(lx * lx + ly * ly + lz * lz)

        val nowMs = timestampNs / 1_000_000L
        if (jolts > 0 && nowMs - windowStart > WINDOW_MS) jolts = 0

        if (magnitude > threshold && nowMs - lastJolt >= MIN_GAP_MS) {
            lastJolt = nowMs
            if (jolts == 0) windowStart = nowMs
            jolts++
            if (jolts >= REQUIRED_JOLTS) {
                jolts = 0
                onShake()
            }
        }
    }

    companion object {
        private const val ALPHA = 0.85f
        private const val WINDOW_MS = 900L
        private const val MIN_GAP_MS = 90L
        private const val REQUIRED_JOLTS = 3

        /** Maps sensitivity 0..1 to an acceleration threshold in m/s^2 (20 -> 8). */
        fun thresholdFor(sensitivity: Float): Float = 20f - sensitivity.coerceIn(0f, 1f) * 12f
    }
}
