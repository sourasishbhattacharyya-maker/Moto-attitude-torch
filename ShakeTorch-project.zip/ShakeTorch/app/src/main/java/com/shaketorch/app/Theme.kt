package com.shaketorch.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Amber = Color(0xFFFFB800)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFC83D), onPrimary = Color(0xFF2B1E00),
    background = Color(0xFF0E0F12), onBackground = Color(0xFFEDEDF0),
    surface = Color(0xFF0E0F12), onSurface = Color(0xFFEDEDF0),
    surfaceContainer = Color(0xFF1A1C21),
    surfaceVariant = Color(0xFF262930), onSurfaceVariant = Color(0xFF9EA2AD),
    secondaryContainer = Color(0xFF3A3220), onSecondaryContainer = Color(0xFFFFE08A),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFFE0A100), onPrimary = Color(0xFF2B1E00),
    background = Color(0xFFF6F5F2), onBackground = Color(0xFF1B1B1F),
    surface = Color(0xFFF6F5F2), onSurface = Color(0xFF1B1B1F),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE6E3DC), onSurfaceVariant = Color(0xFF6B6E78),
    secondaryContainer = Color(0xFFFFEFC2), onSecondaryContainer = Color(0xFF5C4300),
)

@Composable
fun resolveDark(mode: Int): Boolean = when (mode) {
    1 -> false
    2 -> true
    else -> isSystemInDarkTheme()
}

@Composable
fun ShakeTorchTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
