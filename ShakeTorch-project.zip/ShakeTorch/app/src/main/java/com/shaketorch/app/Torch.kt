package com.shaketorch.app

import android.content.Context
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Single source of truth for the flashlight. Uses setTorchMode (no CAMERA permission needed). */
object Torch {
    private val _on = MutableStateFlow(false)
    val isOn: StateFlow<Boolean> = _on.asStateFlow()
    private val _available = MutableStateFlow(true)
    val available: StateFlow<Boolean> = _available.asStateFlow()

    private var manager: CameraManager? = null
    private var cameraId: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val autoOff = Runnable { set(false) }

    fun init(context: Context) {
        if (manager != null) return
        val m = context.applicationContext.getSystemService(CameraManager::class.java)
        if (m == null) {
            _available.value = false
            return
        }
        manager = m
        val ids = runCatching { m.cameraIdList.toList() }.getOrDefault(emptyList())
        fun hasFlash(id: String) = runCatching {
            m.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }.getOrDefault(false)
        fun isBack(id: String) = runCatching {
            m.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) ==
                CameraCharacteristics.LENS_FACING_BACK
        }.getOrDefault(false)

        cameraId = ids.firstOrNull { hasFlash(it) && isBack(it) } ?: ids.firstOrNull { hasFlash(it) }
        _available.value = cameraId != null

        m.registerTorchCallback(object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(id: String, enabled: Boolean) {
                if (id != cameraId) return
                _on.value = enabled
                handler.removeCallbacks(autoOff)
                val minutes = SettingsStore.state.value.timeoutMin
                if (enabled && minutes > 0) handler.postDelayed(autoOff, minutes * 60_000L)
            }
        }, handler)
    }

    fun set(on: Boolean) {
        val id = cameraId ?: return
        try {
            manager?.setTorchMode(id, on)
        } catch (_: CameraAccessException) {
        } catch (_: IllegalArgumentException) {
        }
    }

    fun toggle() = set(!_on.value)
}
