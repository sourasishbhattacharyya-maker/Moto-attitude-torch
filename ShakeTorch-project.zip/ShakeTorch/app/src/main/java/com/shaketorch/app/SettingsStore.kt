package com.shaketorch.app

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val shakeEnabled: Boolean = false,
    /** 0f (hard shake needed) .. 1f (very sensitive) */
    val sensitivity: Float = 0.5f,
    val cooldownMs: Int = 1000,
    /** 0 = never */
    val timeoutMin: Int = 5,
    val vibrate: Boolean = true,
    val workWithScreenOff: Boolean = true,
    /** 0 = system, 1 = light, 2 = dark */
    val theme: Int = 0,
)

object SettingsStore {
    private var prefs: SharedPreferences? = null
    private val _state = MutableStateFlow(AppSettings())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("shaketorch", Context.MODE_PRIVATE)
        prefs = p
        val d = AppSettings()
        _state.value = AppSettings(
            shakeEnabled = p.getBoolean("shake", d.shakeEnabled),
            sensitivity = p.getFloat("sens", d.sensitivity),
            cooldownMs = p.getInt("cooldown", d.cooldownMs),
            timeoutMin = p.getInt("timeout", d.timeoutMin),
            vibrate = p.getBoolean("vibrate", d.vibrate),
            workWithScreenOff = p.getBoolean("screenoff", d.workWithScreenOff),
            theme = p.getInt("theme", d.theme),
        )
    }

    fun update(block: (AppSettings) -> AppSettings) {
        val n = block(_state.value)
        _state.value = n
        prefs?.edit()
            ?.putBoolean("shake", n.shakeEnabled)
            ?.putFloat("sens", n.sensitivity)
            ?.putInt("cooldown", n.cooldownMs)
            ?.putInt("timeout", n.timeoutMin)
            ?.putBoolean("vibrate", n.vibrate)
            ?.putBoolean("screenoff", n.workWithScreenOff)
            ?.putInt("theme", n.theme)
            ?.apply()
    }
}
