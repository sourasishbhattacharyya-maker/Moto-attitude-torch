package com.shaketorch.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val settings by SettingsStore.state.collectAsState()
            val dark = resolveDark(settings.theme)
            DisposableEffect(dark) {
                val style = SystemBarStyle.auto(
                    android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT,
                ) { dark }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            ShakeTorchTheme(dark) { HomeScreen(settings) }
        }
    }
}

private fun setShake(ctx: Context, on: Boolean) {
    SettingsStore.update { it.copy(shakeEnabled = on) }
    if (on) ShakeService.start(ctx) else ShakeService.stop(ctx)
}

@Composable
fun HomeScreen(s: AppSettings) {
    val ctx = LocalContext.current
    val torchOn by Torch.isOn.collectAsState()
    val available by Torch.available.collectAsState()
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { setShake(ctx, true) } // service still works if the notification is denied

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        Text("ShakeTorch", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        val status = when {
            !available -> "No flashlight found on this device"
            torchOn -> "Flashlight is on"
            else -> "Tap or shake to light up"
        }
        AnimatedContent(targetState = status, label = "status") {
            Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(16.dp))
        TorchButton(on = torchOn, enabled = available) { Torch.toggle() }
        Spacer(Modifier.height(16.dp))

        SectionCard("Shake detection") {
            SwitchRow("Shake to toggle", "Runs a lightweight foreground service", s.shakeEnabled) { on ->
                val needsPerm = Build.VERSION.SDK_INT >= 33 && on &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                if (needsPerm) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else setShake(ctx, on)
            }
            val label = when {
                s.sensitivity < 0.33f -> "Low"
                s.sensitivity < 0.67f -> "Medium"
                else -> "High"
            }
            SliderRow("Sensitivity", label, s.sensitivity, 0f..1f, 0) { v ->
                SettingsStore.update { it.copy(sensitivity = v) }
            }
            SliderRow("Cooldown", "%.1f s".format(s.cooldownMs / 1000f), s.cooldownMs.toFloat(), 500f..3000f, 4) { v ->
                SettingsStore.update { it.copy(cooldownMs = v.toInt()) }
            }
            SwitchRow("Work with screen off", "Holds a CPU wake lock; uses more battery", s.workWithScreenOff) { on ->
                SettingsStore.update { it.copy(workWithScreenOff = on) }
                if (s.shakeEnabled) ShakeService.start(ctx)
            }
            TextButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }) { Text("Battery optimization settings") }
        }

        SectionCard("Flashlight") {
            Text("Auto turn-off", style = MaterialTheme.typography.bodyLarge)
            val values = listOf(0, 1, 5, 10, 30)
            ChipRow(
                listOf("Off", "1 min", "5 min", "10 min", "30 min"),
                values.indexOf(s.timeoutMin).coerceAtLeast(0),
            ) { i -> SettingsStore.update { it.copy(timeoutMin = values[i]) } }
            SwitchRow("Vibration feedback", "Short buzz when a shake is detected", s.vibrate) { on ->
                SettingsStore.update { it.copy(vibrate = on) }
            }
        }

        SectionCard("Appearance") {
            ChipRow(listOf("System", "Light", "Dark"), s.theme) { i ->
                SettingsStore.update { it.copy(theme = i) }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun TorchButton(on: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val glow by animateFloatAsState(if (on) 1f else 0f, tween(450), label = "glow")
    val scale by animateFloatAsState(
        if (on) 1f else 0.94f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "scale",
    )
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0.9f, 1.05f,
        infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue",
    )
    val bg by animateColorAsState(
        if (on) Amber else MaterialTheme.colorScheme.surfaceVariant, tween(400), label = "bg",
    )
    val fg by animateColorAsState(
        if (on) Color(0xFF3A2A00) else MaterialTheme.colorScheme.onSurfaceVariant, tween(400), label = "fg",
    )

    Box(Modifier.size(300.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            if (glow > 0.01f) {
                val r = size.minDimension / 2f * pulse
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Amber.copy(alpha = 0.45f * glow), Color.Transparent), radius = r,
                    ),
                    radius = r,
                )
            }
        }
        Box(
            Modifier
                .size(190.dp)
                .scale(scale)
                .clip(CircleShape)
                .background(bg)
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(84.dp)) {
                val w = size.width
                val h = size.height
                val p = Path().apply {
                    moveTo(.58f * w, .04f * h); lineTo(.22f * w, .56f * h); lineTo(.47f * w, .56f * h)
                    lineTo(.40f * w, .96f * h); lineTo(.78f * w, .40f * h); lineTo(.53f * w, .40f * h)
                    close()
                }
                drawPath(p, color = fg)
            }
        }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                title.uppercase(), style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
            )
            content()
        }
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SliderRow(
    title: String, valueLabel: String, value: Float,
    range: ClosedFloatingPointRange<Float>, steps: Int, onChange: (Float) -> Unit,
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(valueLabel, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(label) })
        }
    }
}
