package com.shaketorch.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        SettingsStore.init(context)
        if (SettingsStore.state.value.shakeEnabled) {
            runCatching { ShakeService.start(context) }
        }
    }
}
