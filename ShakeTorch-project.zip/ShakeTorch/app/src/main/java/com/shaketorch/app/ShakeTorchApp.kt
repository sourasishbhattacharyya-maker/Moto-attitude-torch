package com.shaketorch.app

import android.app.Application

class ShakeTorchApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SettingsStore.init(this)
        Torch.init(this)
    }
}
