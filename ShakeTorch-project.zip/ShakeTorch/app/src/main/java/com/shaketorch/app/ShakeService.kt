package com.shaketorch.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class ShakeService : Service(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var wakeLock: PowerManager.WakeLock? = null
    private var registered = false
    private var lastToggle = 0L
    private val detector = ShakeDetector { onShake() }

    override fun onCreate() {
        super.onCreate()
        SettingsStore.init(this)
        Torch.init(this)
        sensorManager = getSystemService(SensorManager::class.java)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                SettingsStore.update { it.copy(shakeEnabled = false) }
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> Torch.toggle()
        }
        goForeground()
        registerSensor()
        updateWakeLock()
        return START_STICKY
    }

    private fun goForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun registerSensor() {
        if (registered) return
        val accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (accel == null) {
            stopSelf()
            return
        }
        detector.reset()
        sensorManager.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME)
        registered = true
    }

    private fun updateWakeLock() {
        val wanted = SettingsStore.state.value.workWithScreenOff
        if (wanted && wakeLock == null) {
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ShakeTorch:shake").apply {
                setReferenceCounted(false)
                acquire()
            }
        } else if (!wanted) {
            releaseWakeLock()
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    override fun onSensorChanged(e: SensorEvent) {
        val s = SettingsStore.state.value
        detector.onSample(
            e.values[0], e.values[1], e.values[2], e.timestamp,
            ShakeDetector.thresholdFor(s.sensitivity),
        )
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun onShake() {
        val s = SettingsStore.state.value
        val now = SystemClock.elapsedRealtime()
        if (now - lastToggle < s.cooldownMs) return
        lastToggle = now
        Torch.toggle()
        if (s.vibrate) vibrate()
    }

    private fun vibrate() {
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            getSystemService(Vibrator::class.java)
        }
        v?.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Shake detection", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Shows while ShakeTorch is listening for shakes"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        fun svc(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, ShakeService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_torch)
            .setContentTitle("ShakeTorch is listening")
            .setContentText("Shake your phone to toggle the flashlight")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, "Toggle", svc(ACTION_TOGGLE, 1))
            .addAction(0, "Stop", svc(ACTION_STOP, 2))
            .build()
    }

    override fun onDestroy() {
        if (registered) sensorManager.unregisterListener(this)
        registered = false
        releaseWakeLock()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "shake"
        private const val NOTIF_ID = 1
        const val ACTION_TOGGLE = "com.shaketorch.app.TOGGLE"
        const val ACTION_STOP = "com.shaketorch.app.STOP"

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, ShakeService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ShakeService::class.java))
        }
    }
}
