# ShakeTorch
Kotlin + Jetpack Compose, minSdk 29 (Android 10), targetSdk 34.

## Build
1. Open this folder in Android Studio (Koala or newer, JDK 17+) and let Gradle sync.
2. Run on a device, or Build > Build APK(s).
   CLI: `gradle wrapper --gradle-version 8.7` once, then `./gradlew assembleDebug`
   -> app/build/outputs/apk/debug/app-debug.apk
   (`./gradlew assembleRelease` gives a minified APK signed with the debug key.)

## Notes
- Shake = 3 strong jolts within 0.9 s after gravity removal. Sensitivity sets the threshold (20 -> 8 m/s^2).
- Screen-off detection needs the foreground service plus a partial wake lock (toggle in settings).
  Some OEMs (Xiaomi, Huawei, Samsung, OnePlus) still kill background apps: exempt it from battery optimization.
- Flashlight uses CameraManager.setTorchMode, so no camera permission is needed.
